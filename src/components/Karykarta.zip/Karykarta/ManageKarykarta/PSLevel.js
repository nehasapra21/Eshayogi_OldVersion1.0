import React, { Component, Fragment } from 'react'

import dropDownArrow from '../../../utils/images/dropdownArrow.svg'

export default class PSLevel extends Component {
  render() {

    let samiti = [ 'Panchayatsamiti_25624206', 'Panchayatsamiti_25624206', 'Panchayatsamiti_25624206' ]

    let designation = [ 'Panchayat Samiti Member', 'Pardhan' ]

    return (
      <Fragment>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Samiti'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
              samiti.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
        </div>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Designation'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
                designation.map((data, index) => {
                  return (
                    <li key={index}>{data}</li>
                  )
                })
            }
          </ul>
        </div>
      </Fragment>
    )
  }
}
