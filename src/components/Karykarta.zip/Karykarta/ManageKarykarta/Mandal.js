import React, { Component, Fragment } from 'react'

import dropDownArrow from '../../../utils/images/dropdownArrow.svg'

export default class PSLevel extends Component {
  render() {

    let mandal = [ 'Mandal_14Ae2a91', 'Mandal_14Ae2a91', 'Mandal_14Ae2a91' ]

    let designation = [ 'Mandal Mantri', 'Mandal Mahamantri', 'Mandal Shakti Kendra Prabhari', 'Mandal Coordinator', 'Mandal Co-Coordinator', 'Mandal Adhyaksh', 'Mandal Up-Adhyaksh', 'Mandal Karyakarni', 'Treasurer', 'Media Incharge', 'Office Incharge', 'Spokesperson' ]

    return (
      <Fragment>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Mandal'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
              mandal.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
        </div>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Designation'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
                designation.map((data, index) => {
                  return (
                    <li key={index}>{data}</li>
                  )
                })
            }
          </ul>
        </div>
      </Fragment>
    )
  }
}
