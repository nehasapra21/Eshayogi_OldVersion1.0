import React, { Component, Fragment } from 'react'

import dropDownArrow from '../../../utils/images/dropdownArrow.svg'

export default class GramPanchayat extends Component {
  render() {

    let panchayat = [ 'Gram_Panchayat_0016E0bd', 'Gram_Panchayat_0016E0bd', 'Gram_Panchayat_0016E0bd' ]

    let designation = [ 'Sarpanch', 'Up Sarpanch', 'Ex. Sarpanch', 'Ward Panch', 'Gram Sevak', 'Gram Panchayat Coordinator', 'Gram Panchayat Co-Coordinator', 'Related ZP Member', 'Related PS Member', 'Gram Panchayat Karyakarta' ]

    return (
      <Fragment>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Panchayat'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
              panchayat.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
        </div>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Designation'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
                designation.map((data, index) => {
                  return (
                    <li key={index}>{data}</li>
                  )
                })
            }
          </ul>
        </div>
      </Fragment>
    )
  }
}
