import React, { Component, Fragment } from 'react'

import dropDownArrow from '../../../utils/images/dropdownArrow.svg'

export default class ShaktiKendra extends Component {
  render() {

    let kendra = [ 'A', 'B', 'C' ]

    let designation = [ 'Shakti Kendra Prabhari', 'Shakti Kendra Sanjoyak', 'Shakti Kendra Karyakarni' ]

    return (
      <Fragment>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Kendra'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
              kendra.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
        </div>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Designation'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
                designation.map((data, index) => {
                  return (
                    <li key={index}>{data}</li>
                  )
                })
            }
          </ul>
        </div>
      </Fragment>
    )
  }
}
