import React, { Component, Fragment } from 'react'

import dropDownArrow from '../../../utils/images/dropdownArrow.svg'

export default class Zila extends Component {
  render() {

    let district = [ 'District_Bcf20dd3', 'District_Bcf20dd3', 'District_Bcf20dd3', 'District_Bcf20dd3', 'District_Bcf20dd3', 'District_Bcf20dd3' ]

    let designation = [ 'Zila Pramukh', 'Zila Parishad', 'Zila Karyakarni' ]

    return (
      <Fragment>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search District'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
              district.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
        </div>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Designation'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
                designation.map((data, index) => {
                  return (
                    <li key={index}>{data}</li>
                  )
                })
            }
          </ul>
        </div>
      </Fragment>
    )
  }
}
