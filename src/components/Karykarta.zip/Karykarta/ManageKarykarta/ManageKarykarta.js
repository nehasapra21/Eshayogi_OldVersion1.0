import React, { Component, Fragment } from 'react'

import Header from '../../header/Header'

import SearchIcon from '../../../utils/images/search.svg'
import dropDownArrow from '../../../utils/images/dropdownArrow.svg'

import Zila from './Zila'
import VidhanSabha from './VidhanSabha'
import Mandal from './Mandal'
import PSLevel from './PSLevel'
import GramPanchayat from './GramPanchayat'
import BoothLevel from './BoothLevel'
import ShaktiKendra from './ShaktiKendra'

import Footer from '../../footer/Footer'
import CopyrightFooter from '../../footer/CopyrightFooter'

import '../Karykarta.css'

export default class ManageKarykarta extends Component {

  constructor(props) {
    super(props)

    this.state = {
      constituencyType : '',
      value : ''
    }

  }

  switchStatement = (constituency) => {
    switch (constituency) {
      case 'Zila Level': return <Zila />

      case 'Vidhan Sabha' : return <VidhanSabha />

      case 'PS Level' : return <PSLevel />

      case 'Mandal Level' : return <Mandal />

      case 'Shakti Kendra' : return <ShaktiKendra />

      case 'Gram Panchayat' : return <GramPanchayat />

      case 'Booth Level' : return <BoothLevel />
    
      default: return null
    }
  }

  render() {

    let areas = [
      {
        area : 'Zila',
        areaState : 'Zila Level'
      },
      {
        area : 'Vidhan Sabha',
        areaState : 'Vidhan Sabha'
      },
      {
        area : 'Panchayat Samiti',
        areaState : 'PS Level'
      },
      {
        area : 'Mandal',
        areaState : 'Mandal Level'
      },
      {
        area : 'Gram Panchayat',
        areaState : 'Gram Panchayat'
      },
      {
        area : 'Shakti Kendra',
        areaState : 'Shakti Kendra'
      },
      {
        area : 'Booth',
        areaState : 'Booth Level'
      }
    ]

    return (
      <div className='NewClientForm'>
        <Header />
        <div className='frame'>
          <div className='FormOuterFrame'>
            <div className='DivHeading'>
              <p className='TxtHeading'>Karyakarta</p>
              <div className='searchBar'>
                <input className='SearchInput' type='text' placeholder='Search' />
                <img className='SearchIcon' src={SearchIcon} alt=''></img>
              </div>
            </div>
            <div className='SearchBars'>
              <div className='SearchBar'>
                <div className='karyakartaSearchBar'>
                  <input className='SearchInput' placeholder='Search' value={this.state.value}></input>
                  <img src={dropDownArrow} alt='' className='SearchIcon' />
                </div>
                <ul className='sahyogiDropdown'>
                  {
                    areas.map((data, index) => {
                      return (
                        <li key={index} onClick={ () => this.setState({ constituencyType : data.areaState, value : data.area }) }>{data.area}</li>
                      )
                    })
                  }
                </ul>
              </div>
              { //code to render search bars after area selected

                this.state.constituencyType === '' ? 
                <Fragment>
                  <div className='SearchBar'>
                    <div className='karyakartaSearchBar'>
                      <input className='SearchInput' placeholder='Please select Area' />
                      <img className='SearchIcon' src={dropDownArrow} alt='' />
                    </div>
                  </div>
                  <div className='SearchBar'>
                    <div className='karyakartaSearchBar'>
                      <input className='SearchInput' placeholder='Please select Area' />
                      <img className='SearchIcon' src={dropDownArrow} alt='' />
                    </div>
                  </div>
                </Fragment>
                : this.switchStatement(this.state.constituencyType)
              }
            </div>
          </div>
          <div className='DashboardFooter'>
            <Footer />
            <CopyrightFooter />
          </div>
        </div>
        <div className='emptyDiv' />
      </div>
    )
  }
}
