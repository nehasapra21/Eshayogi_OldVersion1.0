import React, { Component, Fragment } from 'react'

import dropDownArrow from '../../../utils/images/dropdownArrow.svg'

export default class GramPanchayat extends Component {
  render() {

    let booth = [ 'VSL', 'VSL', 'VSL' ]

    let designation = [ 'Booth Adhyaksh', 'Booth Up-Adhyaksh', 'Booth Karyakarni', 'Booth Prabhari', 'Booth Coordinator', 'Booth Co-Coordinator' ]

    return (
      <Fragment>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Booth'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
              booth.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
        </div>
        <div className='SearchBar'>
          <div className='karyakartaSearchBar'>
            <input className='SearchInput' placeholder='Search Designation'></input>
            <img src={dropDownArrow} alt='' className='SearchIcon' />
          </div>
          <ul className='sahyogiDropdown'>
            {
                designation.map((data, index) => {
                  return (
                    <li key={index}>{data}</li>
                  )
                })
            }
          </ul>
        </div>
      </Fragment>
    )
  }
}
