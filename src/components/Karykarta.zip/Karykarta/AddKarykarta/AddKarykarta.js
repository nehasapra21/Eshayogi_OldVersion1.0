import React, { Component } from 'react'

import Header from '../../header/Header'

import DatePicker from 'react-datepicker'

import '../Karykarta.css'

import Zila from './Zila'
import VidhanSabha from './VidhanSabha'
import Mandal from './Mandal'
import PSLevel from './PSLevel'
import GramPanchayat from './GramPanchayat'
import BoothLevel from './BoothLevel'
import ShaktiKendra from './ShaktiKendra'

import Footer from '../../footer/Footer'
import CopyrightFooter from '../../footer/CopyrightFooter'

export default class AddKarykarta extends Component {

  constructor (props) {
    super (props)

    this.state = {
      constituencyType : 'Zila Level'
    }

  }

  switchStatement = (constituency) => {
    console.log('Constituency ', constituency)
    switch (constituency) {
      case 'Zila Level': return <Zila />

      case 'Vidhan Sabha' : return <VidhanSabha />

      case 'PS Level' : return <PSLevel />

      case 'Mandal Level' : return <Mandal />

      case 'Shakti Kendra' : return <ShaktiKendra />

      case 'Gram Panchayat' : return <GramPanchayat />

      case 'Booth Level' : return <BoothLevel />
    
      default: return 'hello this is default'
    }
  }

  render() {
    return (
      <div className='NewClientForm'>
        <Header />
        <div className='frame'>
          <div className='FormOuterFrame'>
            <div className='DivHeading' style={{ justifyContent : 'center' }}>
              <p className='TxtHeading'>Add Karyakarta</p>
            </div>
            <div className='FormFrame'>
              <form>
                <div className="TxtInputFrame">
                    <p className="TxtInput">Name</p>
                    <p className="TxtStar">*</p>
                </div>
                <input
                  type="text"
                  id="karyakartaName"
                  className="InputFrame"
                  placeholder="25 Characters"
                  required />

                <div className="TxtInputFrame">
                  <p className="TxtInput">Whatsapp Number</p>
                  <p className="TxtStar">*</p>
                </div>
                <input
                  type="tel"
                  id="whatsappNumber"
                  className="InputFrame"
                  placeholder="10 Characters"
                  pattern="[0-9]{10}"
                  maxLength="10"
                  minLength="10"
                  required />

                <div className="TxtInputFrame">
                  <p className="TxtInput">Date of Birth</p>
                  <p className="TxtStar">*</p>
                </div>
                <div >
                  <DatePicker  placeholder="Pick from calendar view" className="InputFrame"/>
                </div>

                <div className="TxtInputFrame">
                  <p className="TxtInput">Constituency</p>
                  <p className="TxtStar">*</p>
                </div>
                <div style={{ marginBottom: "30px" }}>
                  <div className="SelectRadio">
                    <label 
                      className='radiobutton'
                      onClick={() => this.setState({ constituencyType : 'Zila Level' })} >
                      <span className={ this.state.constituencyType === 'Zila Level' ? 'checked' : 'unchecked' } />
                    </label>
                    <p className="TxtRadioInput">Zila</p>
                  </div>
                  <div className="SelectRadio">
                    <label
                      className='radiobutton'
                      onClick={() => this.setState({ constituencyType : 'Vidhan Sabha' })} >
                      <span className={this.state.constituencyType === 'Vidhan Sabha' ? 'checked' : 'unchecked'} />
                    </label>
                    <p className="TxtRadioInput">Vidhan Sabha</p>
                  </div>
                  <div className="SelectRadio">
                    <label
                      className='radiobutton'
                      onClick={() => this.setState({ constituencyType : 'PS Level' })} >
                      <span className={this.state.constituencyType === 'PS Level' ? 'checked' : 'unchecked'} />
                    </label>
                    <p className="TxtRadioInput">Panchayat Samiti</p>
                  </div>
                  <div className="SelectRadio">
                    <label
                      className='radiobutton'
                      onClick={() => this.setState({ constituencyType : 'Mandal Level' })} >
                      <span className={this.state.constituencyType === 'Mandal Level' ? 'checked' : 'unchecked'} />
                    </label>
                    <p className="TxtRadioInput">Mandal</p>
                  </div>
                  <div className="SelectRadio">
                    <label
                      className='radiobutton'
                      onClick={() => this.setState({ constituencyType : 'Shakti Kendra' })} >
                      <span className={this.state.constituencyType === 'Shakti Kendra' ? 'checked' : 'unchecked'} />
                    </label>
                    <p className="TxtRadioInput">Shakti Kendra</p>
                  </div>
                  <div className="SelectRadio">
                    <label
                      className='radiobutton'
                      onClick={() => this.setState({ constituencyType : 'Gram Panchayat' })} >
                      <span className={this.state.constituencyType === 'Gram Panchayat' ? 'checked' : 'unchecked'} />
                    </label>
                    <p className="TxtRadioInput">Gram Panchayat</p>
                  </div>
                  <div className="SelectRadio">
                    <label
                      className='radiobutton'
                      onClick={() => this.setState({ constituencyType : 'Booth Level' })} >
                      <span className={this.state.constituencyType === 'Booth Level' ? 'checked' : 'unchecked'} />
                    </label>
                    <p className="TxtRadioInput">Booth Level</p>
                  </div>
                </div>
                {
                  this.switchStatement(this.state.constituencyType)
                }
                <input type="submit" value="Submit" className="BtnSubmit" />
              </form>
            </div>
          </div>
          <div className='DashboardFooter'>
              <Footer />
              <CopyrightFooter />
          </div>
        </div>
        <div className='emptyDiv'></div>
      </div>
    )
  }
}
