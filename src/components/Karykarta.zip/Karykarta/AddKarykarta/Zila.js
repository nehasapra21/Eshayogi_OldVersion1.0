import React, { Component, Fragment } from 'react'

export default class Zila extends Component {
  render() {

    let district = [ 'District_Bcf20dd3', 'District_Bcf20dd3', 'District_Bcf20dd3', 'District_Bcf20dd3', 'District_Bcf20dd3', 'District_Bcf20dd3' ]

    let designation = [ 'Zila Pramukh', 'Zila Parishad', 'Zila Karyakarni' ]

    return (
      <Fragment>
        <div className='customDropdown'>
          <div className="TxtInputFrame">
            <p className="TxtInput">Select Zila</p>
            <p className="TxtStar">*</p>
          </div>
          <input id="zila" className="InputFrame" placeholder="25 Characters"
            required />
          <ul className='sahyogiDropdown'>
            {
              district.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
        </div>
        <div className='customDropdown'>
          <div className="TxtInputFrame">
            <p className="TxtInput">Designation</p>
            <p className="TxtStar">*</p>
          </div>
          <input id="designation" className="InputFrame" placeholder="Designation"
            required />
          <ul className='sahyogiDropdown'>
              {
                designation.map((data, index) => {
                  return (
                    <li key={index}>{data}</li>
                  )
                })
              }
          </ul>
        </div>
      </Fragment>
    )
  }
}
