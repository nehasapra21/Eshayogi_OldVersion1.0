import React, { Component, Fragment } from 'react'

export default class PSLevel extends Component {
  render() {

    let samiti = [ 'Panchayatsamiti_25624206', 'Panchayatsamiti_25624206', 'Panchayatsamiti_25624206' ]

    let designation = [ 'Panchayat Samiti Member', 'Pardhan' ]

    return (
      <Fragment>
        <div className="TxtInputFrame">
          <p className="TxtInput">Select Panchayat Samiti</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='panchayat-samiti' placeholder='Select Panchayat Samiti' />
          <ul className='sahyogiDropdown'>
            {
              samiti.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
        <div className="TxtInputFrame">
          <p className="TxtInput">Designation</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='designation' placeholder='Designation' /> 
          <ul className='sahyogiDropdown'>
            {
              designation.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
      </Fragment>
    )
  }
}
