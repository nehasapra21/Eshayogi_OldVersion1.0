import React, { Component, Fragment } from 'react'

export default class VidhanSabha extends Component {
  render() {

    let district = [ 'District_5Ab1ed42', 'District_5Ab1ed42', 'District_5Ab1ed42','District_5Ab1ed42', 'District_5Ab1ed42', 'District_5Ab1ed42' ]

    let designation = [ 'Vidhan Sabha Coordinator', 'Vidhan Sabha Co-Coordinator', 'Vidhan Sabha Karyakarini' ]

    return (
      <Fragment>
        <div className="TxtInputFrame">
          <p className="TxtInput">Select Vidhan Sabha</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' placeholder='Select Vidhan Sabha' id='vidhanSabha' />
          <ul className='sahyogiDropdown'>
            {
              district.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>

        <div className="TxtInputFrame">
          <p className="TxtInput">Designation</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' placeholder='Designation' id='designation' />
          <ul className='sahyogiDropdown'>
            {
              designation.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
      </Fragment>
    )
  }
}
