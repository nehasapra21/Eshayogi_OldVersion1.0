import React, { Component, Fragment } from 'react'

export default class GramPanchayat extends Component {
  render() {

    let panchayat = [ 'Gram_Panchayat_0016E0bd', 'Gram_Panchayat_0016E0bd', 'Gram_Panchayat_0016E0bd' ]

    let designation = [ 'Sarpanch', 'Up Sarpanch', 'Ex. Sarpanch', 'Ward Panch', 'Gram Sevak', 'Gram Panchayat Coordinator', 'Gram Panchayat Co-Coordinator', 'Related ZP Member', 'Related PS Member', 'Gram Panchayat Karyakarta' ]

    let category = [ 'A', 'B', 'C' ]

    let revenueVillages = [ 'Revenuevillage_00190B13', 'Revenuevillage_00190B13', 'Revenuevillage_00190B13' ]

    return (
      <Fragment>
        <div className="TxtInputFrame">
          <p className="TxtInput">Select Gram Panchayat</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='gram-panchayat' placeholder='Select Gram Panchayat' />
          <ul className='sahyogiDropdown'>
            {
              panchayat.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>

        <div className="TxtInputFrame">
          <p className="TxtInput">Designation</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='desigantion' placeholder='Designation' />
          <ul className='sahyogiDropdown'>
            {
              designation.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>

        <div className="TxtInputFrame">
          <p className="TxtInput">Category</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='category' placeholder='Category' />
          <ul className='sahyogiDropdown'>
            {
              category.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>

        <div className="TxtInputFrame">
          <p className="TxtInput">Revenue Villages</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='villages' placeholder='Revenue Villages' />
          <ul className='sahyogiDropdown'>
            {
              revenueVillages.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
      </Fragment>
    )
  }
}
