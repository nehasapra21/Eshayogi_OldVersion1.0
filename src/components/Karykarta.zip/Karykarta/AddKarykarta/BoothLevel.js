import React, { Component, Fragment } from 'react'

export default class BoothLevel extends Component {
  render() {

    let booth = [ 'VSL', 'VSL', 'VSL' ]

    let designation = [ 'Booth Adhyaksh', 'Booth Up-Adhyaksh', 'Booth Karyakarni', 'Booth Prabhari', 'Booth Coordinator', 'Booth Co-Coordinator' ]

    return (
      <Fragment>
        <div className="TxtInputFrame">
          <p className="TxtInput">Select Booth</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='booth' placeholder='Select Booth' />
          <ul className='sahyogiDropdown'>
            {
              booth.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>

        <div className="TxtInputFrame">
          <p className="TxtInput">Designation</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='designation' placeholder='Designation' />
          <ul className='sahyogiDropdown'>
            {
              designation.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>

      </Fragment>
    )
  }
}
