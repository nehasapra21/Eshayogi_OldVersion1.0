import React, { Component, Fragment } from 'react'

export default class Mandal extends Component {
  render() {

    let mandal = [ 'Mandal_14Ae2a91', 'Mandal_14Ae2a91', 'Mandal_14Ae2a91' ]

    let designation = [ 'Mandal Mantri', 'Mandal Mahamantri', 'Mandal Shakti Kendra Prabhari', 'Mandal Coordinator', 'Mandal Co-Coordinator', 'Mandal Adhyaksh', 'Mandal Up-Adhyaksh', 'Mandal Karyakarni', 'Treasurer', 'Media Incharge', 'Office Incharge', 'Spokesperson' ]

    return (
      <Fragment>
        <div className="TxtInputFrame">
          <p className="TxtInput">Select Mandal</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='mandal' placeholder='Select Mandal' />
          <ul className='sahyogiDropdown'>
            {
              mandal.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
  
        <div className="TxtInputFrame">
          <p className="TxtInput">Designation</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' />
          <ul className='sahyogiDropdown'>
            {
              designation.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
      </Fragment>
    )
  }
}
