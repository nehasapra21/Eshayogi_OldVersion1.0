import React, { Component, Fragment } from 'react'

export default class ShaktiKendra extends Component {
  render() {

    let kendra = [ 'A', 'B', 'C' ]

    let designation = [ 'Shakti Kendra Prabhari', 'Shakti Kendra Sanjoyak', 'Shakti Kendra Karyakarni' ]

    return (
      <Fragment>
        <div className="TxtInputFrame">
          <p className="TxtInput">Select Shakti Kendra</p>
          <p className="TxtStar">*</p>
        </div>
        <select className='InputFrame' id='shaktiKendra' placeholder='Select Shakti Kendra' />
          <ul className='sahyogiDropdown'>
            {
              kendra.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>

        <div className="TxtInputFrame">
          <p className="TxtInput">Designation</p>
          <p className="TxtStar">*</p>
        </div>
        <input className='InputFrame' id='desigantion' placeholder='Designation' />
          <ul className='sahyogiDropdown'>
            {
              designation.map((data, index) => {
                return (
                  <li key={index}>{data}</li>
                )
              })
            }
          </ul>
      </Fragment>
    )
  }
}
